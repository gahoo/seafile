# -*- coding: utf-8 -*-
SECRET_KEY = "4cr!a*w#zv59(5+&ezh#xa4ozuqu--kc6em_9wm#3r!5(fld_q"
